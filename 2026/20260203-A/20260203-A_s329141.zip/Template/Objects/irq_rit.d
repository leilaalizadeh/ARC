./objects/irq_rit.o: RIT\IRQ_RIT.c \
  C:\Users\aliza\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\LPC17xx.h \
  C:\Users\aliza\AppData\Local\Arm\Packs\ARM\CMSIS\6.1.0\CMSIS\Core\Include\core_cm3.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  C:\Users\aliza\AppData\Local\Arm\Packs\ARM\CMSIS\6.1.0\CMSIS\Core\Include\cmsis_version.h \
  C:\Users\aliza\AppData\Local\Arm\Packs\ARM\CMSIS\6.1.0\CMSIS\Core\Include\cmsis_compiler.h \
  C:\Users\aliza\AppData\Local\Arm\Packs\ARM\CMSIS\6.1.0\CMSIS\Core\Include\cmsis_armclang.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\arm_acle.h \
  C:\Users\aliza\AppData\Local\Arm\Packs\ARM\CMSIS\6.1.0\CMSIS\Core\Include\.\m-profile\cmsis_armclang_m.h \
  C:\Users\aliza\AppData\Local\Arm\Packs\ARM\CMSIS\6.1.0\CMSIS\Core\Include\m-profile\armv7m_mpu.h \
  C:\Users\aliza\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\system_LPC17xx.h \
  RIT\RIT.h RIT\..\Main.h RIT\..\Timer\timer.h RIT\..\Button\button.h \
  RIT\..\LED\led.h RIT\..\joystick\joystick.h RIT\..\RIT\RIT.h \
  RIT\..\ADC\adc.h C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\string.h \
  RIT\..\GLCD\GLCD.h RIT\..\TouchPanel\TouchPanel.h RIT\..\DAC\DAC.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdio.h
